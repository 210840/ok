current_room = 4

#def thanksm():
#   print("\nThanks for playing.\n\n")


print("\n=========== Welcome to Our Adventure Game ===========\n")
print("There’s a person. You just went into an abandoned house because apparently you never watched a single horror movie in your life. You are locked in a generic horror movie plot.\n")
print("You strolled further in. You found 3 doors. \nDoor (1) is wooden and looked old, some bloodstain on the hinge. \nDoor (2) is metallic, it reeks of rust. \nDoor (3) is a glass door. Behind the door you can see a decent bed with a comfy pillow. \n")

while True:
  if current_room == 4:
    roomchoice = input("\nThere are 3 doors \nType: \n0 to quit game. \n1 to enter bloodstained door. \n2 to metallic door. \n3 to glass door.\n")
    if roomchoice == "1":
      current_door = 1
    if roomchoice == "2":
      current_door = 2
    if roomchoice == "3":
      current_door = 3
    if roomchoice == "0":
      thanksm()
      break
  
  if current_room == 1:
    passcode = input("\nBathroom is locked. A passcode is required. \nType: \n0 to quit. \n3 to return to Living room \n\nPasscode: ")
    if passcode == "2458":
      roomchoice = input("\nGreat, you got in! \n\nIn the Bathroom there is a ladder on the floor. What will you do to it? \nType: \n0 to quit \n1 to put close to the air vent \n2 to break it \n3 to return to Living room\n")
      if roomchoice == "1":
        print("\nYou've now escaped to the nearby church. Congratulations you will not die today!\n\n")
        thanksm()
        break
      elif roomchoice == "2":
        print("\nThe demons have won. You will die today.
         current_room = 4\n\n")
        thanksm()
        break
      elif roomchoice == "3":
      elif roomchoice == "0":
        thanksm()
        break
    if passcode == "3":
      current_room = 4 
    if passcode == "0":
      thanksm()
      break

  if current_room == 2:
    print("\nKitchen is unlock, but there is fire in there. You almost got burnt alive!\n")
    roomchoice = input("How will you put the fire out? \nType: \n1 to use mittens \n2 to use tablecloth \n3 to return to Living room \n0 to quit\n")
    if roomchoice == "1":
      print("\nMittens will not save you from fire. You just acidentally die.\n\n")
      thanksm()
      break
    if roomchoice == "2":
      print("\nAfter the fire is out, it lets you see the passcode on the fridge.\n<<< Passcode is 2458. >>>\n")
      current_room = 4
    if roomchoice == "3":
         current_room = 4 
    if roomchoice == "0":
        thanksm()
        break

  if current_room == 3:
    roomchoice = input("\nBasement door is unlocked. It's very dark. There's a shadowy figure. Will you aproach it? \nType: yes or no \nType: \n3 to return to Living room \n0 to quit\n")
    if roomchoice == "yes":
      print("\nYou got killed by a ghost.\n\n")
      thanksm()
      break
    if roomchoice == "no":
      print("\nYou will never know what it is.\n")
      current_room = 4
    if roomchoice == "3":
         current_room = 4
    if roomchoice == "0":
      thanksm()
      break